# Mafia Royale (Render-ready)

Build: `npm run install-all && npm run build`
Start: `npm start`
